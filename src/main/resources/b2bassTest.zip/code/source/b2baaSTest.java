

// -----( IS Java Code Template v1.2
// -----( CREATED: 2015-04-30 12:19:06 IST
// -----( ON-HOST: VMKKEJRIWA02.eur.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import com.softwareag.util.IDataMap;
import com.wm.app.b2b.server.PackageManager;
import com.wm.data.IData;
// --- <<IS-END-IMPORTS>> ---

public final class b2baaSTest

{
	// ---( internal utility methods )---

	final static b2baaSTest _instance = new b2baaSTest();

	static b2baaSTest _newInstance() { return new b2baaSTest(); }

	static b2baaSTest _cast(Object o) { return (b2baaSTest)o; }

	// ---( server methods )---




	public static final void readFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(readFile)>> ---
		// @sigtype java 3.5
		// [i] field:0:required fileName
		// [o] field:0:required contents
		IDataMap pipelineMap = new IDataMap(pipeline);
		/*String fileName = pipelineMap.getAsString("fileName");
		
		if(fileName == null) {
			throw new ServiceException("fileName field is mandatory");
		}*/
		
		File folder = new File(PackageManager.getPackageDir(), "b2bassTest/resources");
		File[] listOfFiles = folder.listFiles();
		
		if(listOfFiles != null && listOfFiles.length > 0) {
			BufferedReader reader = null;
			try {
				reader = new BufferedReader( new FileReader(listOfFiles[0]));
				String         line = null;
				StringBuilder  stringBuilder = new StringBuilder();
				String         ls = System.getProperty("line.separator");
		
				while( ( line = reader.readLine() ) != null ) {
					stringBuilder.append( line );
					stringBuilder.append( ls );
				}
		
				pipelineMap.put("contents", stringBuilder.toString());
		
				if(reader != null) {
					reader.close();
					boolean delete = listOfFiles[0].delete();
					if(!delete) {
						throw new ServiceException("Provided file " + listOfFiles[0].getName() + " could not be deleted.");
					}
		
					reader = null;
				}
		
			} catch (Exception e) {
				throw new ServiceException(e);
			} finally {
				if(reader != null) {
					try {
						reader.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}
		// --- <<IS-END>> ---

                
	}
}

